﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using midTerm.Data.Entities;
using SurveyAssignment1.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SurveyAssignment1.Services
{
    public class AnswersService : IAnswersService
    {
        public SurveyContext _context { get; set; }
        public AnswersService(SurveyContext context)
        {
            _context = context;
        }
        public async Task<ActionResult<Answers>> CreateAnswers(Answers answers)
        {
            _context.Answers.Add(answers);
            await _context.SaveChangesAsync();

            return answers;
        }

        public async Task<ActionResult<Answers>> DeleteAnswers(int id)
        {
            var answers = await _context.Answers.FindAsync(id);
            if (answers == null)
            {
                return null;
            }

            _context.Answers.Remove(answers);
            await _context.SaveChangesAsync();

            return answers;
        }

        public async Task<ActionResult<IEnumerable<Answers>>> GetAnswers()
        {
            return await _context.Answers.ToListAsync();
        }

        public async Task<IActionResult> UpdateAnswers(int id, Answers answers)
        {
            if (id != answers.Id)
            {
                return null;
            }

            _context.Entry(answers).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AnswersExists(id))
                {
                    return null;
                }
                else
                {
                    throw;
                }
            }

            return null;
        }

        private bool AnswersExists(int id)
        {
            return _context.Answers.Any(e => e.Id == id);
        }
    }
}
