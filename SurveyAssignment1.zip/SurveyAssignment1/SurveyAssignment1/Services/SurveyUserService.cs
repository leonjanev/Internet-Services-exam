﻿using SurveyAssignment1.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SurveyAssignment1.Services
{
    public class SurveyUserService: ISurveyUserService
    {
    }
}
