﻿using midTerm.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SurveyAssignment1.Dto
{
    public class AnswersDto
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int OptionId { get; set; }

        public OptionDto Option { get; set; }

        public SurveyUserDto User { get; set; }
    }
}
