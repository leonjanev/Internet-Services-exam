﻿using Microsoft.AspNetCore.Mvc;
using midTerm.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SurveyAssignment1
{
    public interface IAnswersService
    {
        Task<ActionResult<IEnumerable<Answers>>> GetAnswers();
        Task<ActionResult<Answers>> CreateAnswers(Answers answers);
        Task<ActionResult<Answers>> DeleteAnswers(int id);
        Task<IActionResult> UpdateAnswers(int id, Answers answers);
    }
}
