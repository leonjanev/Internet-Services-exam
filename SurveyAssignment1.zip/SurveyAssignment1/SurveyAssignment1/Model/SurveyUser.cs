﻿using System;
using System.ComponentModel.DataAnnotations;
using midTerm.Data.Enums;

namespace midTerm.Data.Entities
{
    public class SurveyUser
    {
        public int Id { get; set; }
        [Required]
        [MaxLength(50)]
        public string FirstName { get; set; }
        [Required]
        [MaxLength(50)]
        public string LastName { get; set; }
        public DateTime? DoB { get; set; }
        [Required]
        public Gender Gender { get; set; }
        [Required]
        public string Country { get; set; }
    }
}
