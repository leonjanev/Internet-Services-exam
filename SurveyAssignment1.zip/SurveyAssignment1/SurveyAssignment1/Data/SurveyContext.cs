﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using midTerm.Data.Entities;

namespace SurveyAssignment1.Data
{
    public class SurveyContext : DbContext
    {
        public SurveyContext (DbContextOptions<SurveyContext> options)
            : base(options)
        {
        }

        public DbSet<midTerm.Data.Entities.SurveyUser> SurveyUser { get; set; }

        public DbSet<midTerm.Data.Entities.Answers> Answers { get; set; }
    }
}
