﻿using AutoMapper;
using midTerm.Data.Entities;
using SurveyAssignment1.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SurveyAssignment1.Mapper
{
    public class SurveyProfile: Profile
    {

        public SurveyProfile()
        {

            CreateMap<Option, OptionDto>();
            CreateMap<Option, OptionDto>().ReverseMap();
            CreateMap<Question, QuestionDto>();
            CreateMap<Question, QuestionDto>().ReverseMap();
            CreateMap<List<Answers>, List<AnswersDto>>();
            CreateMap<List<Answers>, List<AnswersDto>>().ReverseMap();
            CreateMap<List<SurveyUser>, List<SurveyUserDto>>();
            CreateMap<List<SurveyUser>, List<SurveyUserDto>>().ReverseMap();
            CreateMap<List<Option>, List<OptionDto>>();
            CreateMap<List<Option>, List<OptionDto>>().ReverseMap();
            CreateMap<List<Question>, List<QuestionDto>>();
            CreateMap<List<Question>, List<QuestionDto>>().ReverseMap();

            CreateMap<SurveyUser, SurveyUserDto>();
            CreateMap<SurveyUser, SurveyUserDto>().ReverseMap();
            CreateMap<Answers, AnswersDto>();
            CreateMap<Answers, AnswersDto>().ReverseMap();
        }
    }
}
