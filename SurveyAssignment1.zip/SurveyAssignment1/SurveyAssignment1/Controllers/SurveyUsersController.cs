﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SurveyAssignment1.Data;
using midTerm.Data.Entities;
using SurveyAssignment1.Dto;
using AutoMapper;

namespace SurveyAssignment1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SurveyUsersController : ControllerBase
    {
        private readonly SurveyContext _context;
        private readonly IMapper _mapper;

        public SurveyUsersController(SurveyContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;

        }


        [HttpGet]
        public async Task<ActionResult<IEnumerable<SurveyUserDto>>> GetSurveyUser()
        {
            var users = await _context.SurveyUser.ToListAsync();

            return _mapper.Map<List<SurveyUserDto>>(users);
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<SurveyUser>> GetSurveyUser(int id)
        {
            var surveyUser = await _context.SurveyUser.FindAsync(id);

            if (surveyUser == null)
            {
                return NotFound();
            }

            return surveyUser;
        }


        [HttpPut("{id}")]
        public async Task<IActionResult> PutSurveyUser(int id, SurveyUserDto surveyUserDto)
        {
            var surveyUser = _mapper.Map<SurveyUser>(surveyUserDto);
            if (id != surveyUser.Id)
            {
                return BadRequest();
            }

            _context.Entry(surveyUser).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SurveyUserExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }


        [HttpPost]
        public async Task<ActionResult<SurveyUserDto>> PostSurveyUser(SurveyUserDto surveyUserDto)
        {
            var surveyUser = _mapper.Map<SurveyUser>(surveyUserDto);
            _context.SurveyUser.Add(surveyUser);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetSurveyUser", new { id = surveyUser.Id }, surveyUserDto);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<SurveyUser>> DeleteSurveyUser(int id)
        {
            var surveyUser = await _context.SurveyUser.FindAsync(id);
            if (surveyUser == null)
            {
                return NotFound();
            }

            _context.SurveyUser.Remove(surveyUser);
            await _context.SaveChangesAsync();

            return surveyUser;
        }

        private bool SurveyUserExists(int id)
        {
            return _context.SurveyUser.Any(e => e.Id == id);
        }
    }
}
