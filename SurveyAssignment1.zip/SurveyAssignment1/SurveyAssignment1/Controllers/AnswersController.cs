﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SurveyAssignment1.Data;
using midTerm.Data.Entities;
using AutoMapper;
using SurveyAssignment1.Dto;

namespace SurveyAssignment1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AnswersController : ControllerBase
    {
        private readonly SurveyContext _context;
        private readonly IAnswersService _answersService;
        private readonly IMapper _mapper;

        public AnswersController(SurveyContext context, IAnswersService answersService, IMapper mapper)
        {
            _context = context;
            _answersService = answersService;
            _mapper = mapper;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<AnswersDto>>> GetAnswers()
        {
            var answers = await _answersService.GetAnswers();

            return answers.Value.Select(x => _mapper.Map<AnswersDto>(x)).ToList();
        }
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAnswers(int id, AnswersDto answersDto)
        {
            var answers = _mapper.Map<Answers>(answersDto);
            var result = await _answersService.UpdateAnswers(id, answers);

            if(result != null)
            {
                return Ok();
            }

            return NoContent();
        }

        [HttpPost]
        public async Task<ActionResult<Answers>> PostAnswers(AnswersDto answersDto)
        {
            var answers = _mapper.Map<Answers>(answersDto);
            return await _answersService.CreateAnswers(answers);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<Answers>> DeleteAnswers(int id)
        {
            var result = await _answersService.DeleteAnswers(id);

            if(result != null)
            {
                return Ok();
            }
            return NoContent();
        }

        private bool AnswersExists(int id)
        {
            return _context.Answers.Any(e => e.Id == id);
        }
    }
}
